package com.report;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootModuloThymeleafPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootModuloThymeleafPracticeApplication.class, args);
	}

}
